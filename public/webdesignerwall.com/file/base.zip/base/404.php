<?php get_header(); ?>

	<div id="content" class="clearfix">
	
		<h1 class="page-title"><?php _e('404','themify'); ?></h1>	
		<p><?php _e( 'Page not found.', 'themify' ); ?></p>	
		
	</div>
	<!-- /#content -->
		
<?php get_sidebar(); ?>
	
<?php get_footer(); ?>